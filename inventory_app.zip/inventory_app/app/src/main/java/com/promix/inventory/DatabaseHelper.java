package com.promix.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL)");
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, sku TEXT UNIQUE, quantity INTEGER NOT NULL DEFAULT 0, min_quantity INTEGER NOT NULL DEFAULT 5, notes TEXT)");
        db.execSQL("CREATE TABLE movements (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, type TEXT NOT NULL, qty INTEGER NOT NULL, username TEXT, created_at TEXT NOT NULL, FOREIGN KEY(product_id) REFERENCES products(id))");

        db.execSQL("INSERT INTO users(name,username,password,role) VALUES('المدير','admin','1234','مدير')");
        db.execSQL("INSERT INTO products(name,category,sku,quantity,min_quantity,notes) VALUES('بطارية 200 أمبير','بطاريات','BAT-200',12,3,'مثال تجريبي')");
        db.execSQL("INSERT INTO products(name,category,sku,quantity,min_quantity,notes) VALUES('لوح طاقة 550 واط','ألواح طاقة','PV-550',20,5,'مثال تجريبي')");
        db.execSQL("INSERT INTO products(name,category,sku,quantity,min_quantity,notes) VALUES('انفرتر 5 كيلو','انفرترات','INV-5K',7,2,'مثال تجريبي')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS movements");
        db.execSQL("DROP TABLE IF EXISTS products");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public boolean login(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM users WHERE username=? AND password=?", new String[]{username, password});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public Cursor getProducts(String search) {
        SQLiteDatabase db = getReadableDatabase();
        if (search == null || search.trim().isEmpty()) {
            return db.rawQuery("SELECT * FROM products ORDER BY name", null);
        }
        String q = "%" + search.trim() + "%";
        return db.rawQuery("SELECT * FROM products WHERE name LIKE ? OR category LIKE ? OR sku LIKE ? ORDER BY name", new String[]{q,q,q});
    }

    public Cursor getLowStock() {
        return getReadableDatabase().rawQuery("SELECT * FROM products WHERE quantity <= min_quantity ORDER BY quantity ASC", null);
    }

    public long addProduct(String name, String category, String sku, int qty, int minQty, String notes) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("category", category);
        v.put("sku", sku);
        v.put("quantity", qty);
        v.put("min_quantity", minQty);
        v.put("notes", notes);
        return getWritableDatabase().insert("products", null, v);
    }

    public boolean deleteProduct(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("movements", "product_id=?", new String[]{String.valueOf(id)});
        return db.delete("products", "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean moveStock(long productId, int delta, String type, String username) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor c = db.rawQuery("SELECT quantity FROM products WHERE id=?", new String[]{String.valueOf(productId)});
            if (!c.moveToFirst()) { c.close(); return false; }
            int current = c.getInt(0);
            c.close();
            int next = current + delta;
            if (next < 0) return false;

            ContentValues p = new ContentValues();
            p.put("quantity", next);
            db.update("products", p, "id=?", new String[]{String.valueOf(productId)});

            ContentValues m = new ContentValues();
            m.put("product_id", productId);
            m.put("type", type);
            m.put("qty", Math.abs(delta));
            m.put("username", username);
            m.put("created_at", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date()));
            db.insert("movements", null, m);
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    public Cursor getMovements() {
        return getReadableDatabase().rawQuery(
                "SELECT m.id,p.name,m.type,m.qty,m.username,m.created_at FROM movements m JOIN products p ON p.id=m.product_id ORDER BY m.id DESC LIMIT 100", null);
    }

    public long addUser(String name, String username, String password, String role) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("username", username);
        v.put("password", password);
        v.put("role", role);
        return getWritableDatabase().insert("users", null, v);
    }

    public Cursor getUsers() {
        return getReadableDatabase().rawQuery("SELECT id,name,username,role FROM users ORDER BY name", null);
    }

    public int productCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM products", null);
        c.moveToFirst(); int n = c.getInt(0); c.close(); return n;
    }

    public int totalUnits() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(quantity),0) FROM products", null);
        c.moveToFirst(); int n = c.getInt(0); c.close(); return n;
    }

    public int lowStockCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM products WHERE quantity <= min_quantity", null);
        c.moveToFirst(); int n = c.getInt(0); c.close(); return n;
    }
}
